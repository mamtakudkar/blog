from django.contrib import admin
from Blogapp.models import Blog

# Register your models here.
class BlogAdmin(admin.ModelAdmin):
    list_display=['title']
    prepopulated_fields={'slug':('title',)}

admin.site.register(Blog,BlogAdmin)